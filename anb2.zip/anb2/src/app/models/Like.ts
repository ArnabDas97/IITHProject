export class Like{
    public id : number;
    public mediaId : number;
    public userId : number;
    public likerId : number;
    public likerName : string;
    public like : string;
    constructor(){}
}