package com.social.main;

import java.sql.SQLException;

import com.social.user.controller.UserFunctions;
import com.social.user.input.UserInput;
import com.social.user.mainRegistration.UserRegistration;
import com.social.user.pojo.User;

public class Main {

	public static void main(String[] args) throws SQLException {
		UserInput userInput = new UserInput();
		UserRegistration userRegistration = new UserRegistration();
		UserFunctions userFunctions = new UserFunctions();

		System.out.println("Welcome to Pixogram");
		System.out.println("Would you like to 1.Sign In or 2.Register?");
		int choice = userInput.getChoice();
		if (choice == 1) {
			User user = userFunctions.login();
			if (user != null) {
				userFunctions.userActions(user);
			} else {
				System.out.println("Login Failed");
			}
		} else {
			userRegistration.registerUser();
		}
	}
}
