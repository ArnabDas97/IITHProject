package com.social.user.controller;

import java.sql.SQLException;

import com.social.image.display.ImageOutput;
import com.social.user.display.UserOutput;
import com.social.user.input.UserInput;
import com.social.user.pojo.User;
import com.social.user.service.UserService;

public class UserFunctions {
	UserInput userInput = new UserInput();
	UserService userService = new UserService();
	ImageOutput imageOutput = new ImageOutput();
	UserOutput userOutput = new UserOutput();

	public User login() throws SQLException {
		User user = userInput.loginInput();
		user = userService.checkUser(user);
		return user;
	}

	public void userActions(User user) throws SQLException {
		System.out.println("What would you like to do?");
		System.out.println("1. Edit Profile\n2.View All Users\n3.Add/View Images");
		int choice = userInput.getChoice();
		if (choice == 1) {
			editProfile(user);
		} else if (choice == 2) {
			userOutput.listUsers();
		} else if (choice == 3) {
			imageOutput.imageFunctions();
		}
	}

	public void editProfile(User user) throws SQLException {
		System.out.println("What do you want to modify?");
		System.out.println("1.First Name\n2.Last Name\n3.User Name");
		System.out.println("4.Email\n5.Password\n6.Profile Picture");
		int choice = userInput.getChoice();
		switch (choice) {
		case 1:
			System.out.println("Enter First Name");
			user.setFirstName(userInput.getString());
			break;
		case 2:
			System.out.println("Enter Last Name");
			user.setLastName(userInput.getString());
			break;
		case 3:
			System.out.println("Enter User Name");
			user.setUserName(userInput.getString());
			break;
		case 4:
			System.out.println("Enter Email");
			user.setEmail(userInput.getString());
			break;
		case 5:
			System.out.println("Enter Password");
			user.setPassword(userInput.getString());
			break;
		case 6:
			System.out.println("Enter Profile Picture URL");
			user.setProfilePicture(userInput.getString());
			break;
		}
		int status = userService.updateUser(user);
		if (status != 0) {
			System.out.println("Update Successful");
		} else {
			System.out.println("Update Failed");
		}
	}

}
