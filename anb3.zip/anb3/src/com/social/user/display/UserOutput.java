package com.social.user.display;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.social.user.input.UserInput;
import com.social.user.pojo.User;
import com.social.user.service.UserService;

public class UserOutput {
	UserInput userInput = new UserInput();
	UserService userService = new UserService();

	public void listUsers() throws SQLException {
		System.out.println("Enter 1 to sort the users by their First Name or 2 to sort by Last Name");
		int choice = userInput.getChoice();
		List<User> userList = new ArrayList<User>();
		userList = userService.getUserListByChoice(choice);
		System.out.println(userList);
	}

	/*
	 * public static void main(String args[]) throws SQLException {
	 * System.out.println("Do you wish to 1.Register? or 2.View the Users?");
	 * UserOutput userOutput = new UserOutput(); int choice =
	 * userOutput.userInput.getChoice();
	 * 
	 * if (choice == 1) { UserRegistration userRegistration = new
	 * UserRegistration(); userRegistration.registerUser(); } else {
	 * userOutput.listUsers(); }
	 * 
	 * }
	 */
}
