package com.social.user.mainRegistration;

import java.sql.SQLException;

import com.social.user.database.UserDB;
import com.social.user.input.UserInput;
import com.social.user.pojo.User;
import com.social.user.service.UserService;
import com.social.user.utilities.UserValidation;

public class UserRegistration {
	UserInput userInput = new UserInput();
	UserValidation userValidation = new UserValidation();
	UserDB userDB = new UserDB();
	UserService userService = new UserService();

	public void registerUser() throws SQLException {
		User user = userInput.getUserRegistrationInput();

		String message = userValidation.validateUser(user);

		if (message.equals("success")) {
			userService.registerUser(user);
			System.out.println("Registration Successful");
		} else {
			System.out.println("Validation Error : " + message);
		}
	}
}
