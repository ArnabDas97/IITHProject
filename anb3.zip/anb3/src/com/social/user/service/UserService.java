package com.social.user.service;

import java.sql.SQLException;
import java.util.List;

import com.social.user.database.UserDB;
import com.social.user.pojo.User;

public class UserService {
	UserDB userDB = new UserDB();

	public List<User> getUserListByChoice(int choice) throws SQLException {

		return userDB.getUserListByChoice(choice);

	}

	public void registerUser(User user) throws SQLException {
		userDB.registerUser(user);
	}

	public User checkUser(User user) throws SQLException {

		return userDB.checkUser(user);
	}

	public int updateUser(User user) throws SQLException {
		return userDB.updateUser(user);

	}
}
