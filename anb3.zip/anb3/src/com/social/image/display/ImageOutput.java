package com.social.image.display;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.social.image.controller.MultipleImageInput;
import com.social.image.controller.SingleImageInput;
import com.social.image.input.ImageInput;
import com.social.image.pojo.Image;
import com.social.image.service.ImageService;

public class ImageOutput {
	ImageInput imageInput = new ImageInput();
	ImageService imageService = new ImageService();

	public void listImages() throws SQLException {
		List<Image> imageList = new ArrayList<Image>();
		imageList = imageService.getImages();
		System.out.println(imageList);
	}

	public void imageFunctions() throws SQLException {

		System.out.println("Do you want to 1.Store image or 2.Get Image Details");
		int choice = imageInput.getChoice();
		if (choice == 1) {
			System.out.println("Do you want to insert 1.Single Image or 2.Multiple Images?");
			int ch = imageInput.getChoice();
			if (ch == 1) {
				SingleImageInput singleImageInput = new SingleImageInput();
				singleImageInput.addSingleImage();
			} else {
				MultipleImageInput multipleImageInput = new MultipleImageInput();
				multipleImageInput.addMultipleImages();
			}
		} else {
			listImages();
		}
	}
}
