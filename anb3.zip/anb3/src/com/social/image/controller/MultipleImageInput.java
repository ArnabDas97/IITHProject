package com.social.image.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.social.image.input.ImageInput;
import com.social.image.pojo.Image;
import com.social.image.service.ImageService;
import com.social.image.utilities.ImageValidation;

public class MultipleImageInput {
	ImageInput imageInput = new ImageInput();
	ImageValidation imageValidation = new ImageValidation();
	ImageService imageService = new ImageService();

	public void addMultipleImages() throws SQLException {
		System.out.println("Enter the number of images you wish to save");
		int choice = imageInput.getChoice();
		List<Image> imageList = new ArrayList<Image>();
		for (int i = 0; i < choice; i++) {
			Image image = imageInput.getImage();
			imageList.add(image);
			// String message = imageValidation.validateImage(imageList.get(i));
			// if (message.equals("success")) {
			// imageService.storeImage(imageList.get(i));
			// System.out.println("Image " + (i + 1) + " stored successfully");
			// } else {
			// System.out.println("Image " + (i + 1) + " Validation Error : " + message);
			// }

		}
		for (int i = 0; i < choice; i++) {
			String message = imageValidation.validateImage(imageList.get(i));
			if (message.equals("success")) {
				imageService.storeImage(imageList.get(i));
				System.out.println("Image " + (i + 1) + " stored successfully");
			} else {
				System.out.println("Image " + (i + 1) + " Validation Error : " + message);
			}
		}
	}
}
