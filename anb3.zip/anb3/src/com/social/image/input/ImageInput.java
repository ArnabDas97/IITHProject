package com.social.image.input;

import java.util.Scanner;

import com.social.image.pojo.Image;

public class ImageInput {

	Scanner s = new Scanner(System.in);

	public Image getImage() {
		Image image = new Image();
		System.out.println("Enter Image Name");
		image.setImageName(s.nextLine());
		System.out.println("Enter Image Title");
		image.setTitle(s.nextLine());
		System.out.println("Enter Image Description");
		image.setDescription(s.nextLine());
		System.out.println("Enter Image URL");
		image.setImageUrl(s.nextLine());

		return image;
	}

	public int getChoice() {
		int choice = s.nextInt();
		s.nextLine();
		return choice;
	}

}
