package com.social.image.utilities;

import com.social.image.pojo.Image;

public class ImageValidation {
	public String validateImage(Image image) {
		String message = "";
		boolean valid = true;

		if (image.getImageName() == null || (!image.getImageName().matches("[a-zA-Z0-9]*"))) {
			message = message + "\n" + "Image name can be alphanumeric only";
			valid = false;
		}

		if (image.getTitle() == null || (!image.getTitle().matches("[a-zA-Z0-9]*"))) {
			message = message + "\n" + "Image title can be alphanumeric only";
			valid = false;
		}

		if (image.getDescription().length() < 10 || image.getDescription().length() > 255) {
			message = message + "\n" + "Image description must be between 10 and 255 characters";
			valid = false;
		}

		String regex = "([^\\s]+(\\.(?i)(jpg|png|gif|bmp))$)";
		if (image.getImageUrl() == null || !image.getImageUrl().matches(regex)) {
			message = message + "\n" + "Enter a valid image URL";
			valid = false;
		}

		if (valid == true) {
			return "success";
		} else {
			return message;
		}
	}
}
