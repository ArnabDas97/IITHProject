package com.social.image.pojo;

public class Image {
	private int imageId;
	private String imageName;
	private String title;
	private String description;
	private String imageUrl;

	public Image() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Image(int imageId, String imageName, String title, String description, String imageUrl) {
		super();
		this.imageId = imageId;
		this.imageName = imageName;
		this.title = title;
		this.description = description;
		this.imageUrl = imageUrl;
	}

	public int getImageId() {
		return imageId;
	}

	public void setImageId(int imageId) {
		this.imageId = imageId;
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	@Override
	public String toString() {
		return "Image [imageId=" + imageId + ", imageName=" + imageName + ", title=" + title + ", description="
				+ description + ", imageUrl=" + imageUrl + "]";
	}

}
