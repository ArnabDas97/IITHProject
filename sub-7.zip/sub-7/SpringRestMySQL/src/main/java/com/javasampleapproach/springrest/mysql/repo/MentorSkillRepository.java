package com.javasampleapproach.springrest.mysql.repo;

import java.util.Collection;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.javasampleapproach.springrest.mysql.model.MentorSkill;

public interface MentorSkillRepository extends JpaRepository<MentorSkill, Long> {

	@Query(value="select * from mentor_skill ms where ms.technology_name like ?1", nativeQuery = true)
	List<MentorSkill> findTimeOfCourse(String technologyName);

	@Query(value="select * from mentor_skill ms where ms.technology_name like ?1 and ms.toc like ?2 and ms.start_date like ?3",nativeQuery = true)
	List<MentorSkill> findMentorDetails(String technologyName, String timeOfCourse, String startDate);

	
	  @Query(
	  value="select ms.id,ms.end_date,ms.prerequites,ms.self_rating,ms.start_date,ms.technology_name,ms.toc,ms.trainings_delivered,ms.yoe,ms.technology_id,ms.status from mentor_skill ms,mentor_user_details mud where ms.id=mud.mentorskill_id and mud.user_id=?1 and ms.status like ?2"
	  ,nativeQuery = true) 
	  List<MentorSkill> findOngoingTrainings(Long id, String status);

	  @Query(value="select ms.id,ms.end_date,ms.prerequites,ms.self_rating,ms.start_date,ms.technology_name,ms.toc,ms.trainings_delivered,ms.yoe,ms.technology_id,ms.status from mentor_skill ms,mentor_user_details mud where ms.id=mud.mentorskill_id and mud.user_id=?1 and ms.status like ?2"
			  ,nativeQuery = true) 
	List<MentorSkill> findCompletedTrainings(Long id, String status);
	
	

	


	
}
