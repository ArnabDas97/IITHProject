package com.javasampleapproach.springrest.mysql.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import com.javasampleapproach.springrest.mysql.model.Mentor;
import com.javasampleapproach.springrest.mysql.model.MentorSkill;
import com.javasampleapproach.springrest.mysql.model.Technology;
import com.javasampleapproach.springrest.mysql.model.User;

public interface UserService {

	/* public Optional<User> findById(Long id); */



	public List<Technology> findAllTechnologies();

	public User createUser(User user);

	public Optional<User> findByEmailAndPassword(String username, String password);

	public Optional<User> findById(Long id);

	public List<MentorSkill> findTechnology_name();

	public List<MentorSkill> getTimeOfCourse(String technologyName);

	public List<MentorSkill> getMentorDetails(String technologyName,String timeOfCourse,String startDate);

	
	
	  public List<MentorSkill> getOngoingTrainings(String technologyName, String
	  timeOfCourse, String status);

	public List<MentorSkill> getCompletedTrainings(String username, String password, String status);
	 
	 

	
}
