package com.javasampleapproach.springrest.mysql.repo;

import java.util.Date;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.javasampleapproach.springrest.mysql.model.Mentor;

public interface MentorRepository  extends JpaRepository<Mentor, Long> {
	
	@Query(value = "SELECT m.username,ms.year_of_experience,ms.self_rating,ms.trainings_delivered"
			+ "from mentor m ,mentor_skill ms where m.id=ms.mentor_id" , 
			nativeQuery = true)
	Set<Mentor> findByNameAndStartTimeAndStartDate(String name, String timeOfCourse, String startDate);

}
