import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  
  private baseUrl = 'http://localhost:8916/api/user';
  constructor(private http: HttpClient) { }
  getUserAfterLogin(username: string, password: string): Observable<any>{
    return this.http.get(`${this.baseUrl}/${username}/${password}`);
  }
  // getUser(id:number): Observable<any>{
  //   return this.http.get(`${this.baseUrl}/${id}}`);
  // }
  createUser(user: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}` + `/create`,user);
  }

  getTechnologyName(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+ `/getTechnologyName`);
  }

  getToc(technologyName:string): Observable<any> {
    return this.http.get(`${this.baseUrl}/${technologyName}`);
  }

  getMentorDetails(technologyName:string, timeOfCourse:string, startDate:string):Observable<any>{
    return this.http.get(`${this.baseUrl}/${technologyName}/${timeOfCourse}/${startDate}`);
  }

  getOngoingTrainings(username:string,password:string,status:string):Observable<any>{
    return this.http.get(`${this.baseUrl}`+`/getOngoingTrainings`+`/${username}/${password}/${status}`);
  }
  getCompletedTrainings(username:string,password:string,status:string):Observable<any>{
    return this.http.get(`${this.baseUrl}`+`/getCompletedTrainings`+`/${username}/${password}/${status}`);
  }

}
