import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { UserSignupComponent } from './user-signup/user-signup.component';
import { GetUserComponent } from './get-user/get-user.component';
import { LoginHeaderComponent } from './login-header/login-header.component';
import { SearchTrainingsComponent } from './search-trainings/search-trainings.component';
import {ReactiveFormsModule} from '@angular/forms';
import { OngoingTrainingsComponent } from './ongoing-trainings/ongoing-trainings.component';
import { CompletedTrainingsComponent } from './completed-trainings/completed-trainings.component';

@NgModule({
  declarations: [
    AppComponent,
    UserLoginComponent,
    UserSignupComponent,
    GetUserComponent,
    LoginHeaderComponent,
    SearchTrainingsComponent,
    OngoingTrainingsComponent,
    CompletedTrainingsComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
