import { Component, OnInit, Input } from '@angular/core';
import { UserService } from '../user.service';
import { ActivatedRoute,Router, Params} from '@angular/router';
import { User } from '../user';
import { MentorSkill } from '../mentorskill';

@Component({
  selector: 'app-get-user',
  templateUrl: './get-user.component.html',
  styleUrls: ['./get-user.component.css']
})
export class GetUserComponent implements OnInit {

  user:User;
  mentorSkill:MentorSkill[];
  
  constructor(private route:ActivatedRoute,private userService:UserService,private router:Router) { }

 

  ngOnInit() {
    this.route.params.subscribe((params: Params)=>{
      let username=params['username'];
      let password=params['password'];
 
      this.userService.getUserAfterLogin(username,password)
      .subscribe(user=>this.user=user);
  
    });}
    
goToSearchTrainings()
{
  
  this.route.params.subscribe((params: Params)=>{
    let username=params['username'];
    let password=params['password'];

    this.userService.getUserAfterLogin(username,password)
    .subscribe(user=>this.user=user);
    if(this.user!=null)
    this.router.navigate(['/searchtrainings',username,password]);

  });
  

}
goToProfile()
{
  this.route.params.subscribe((params: Params)=>{
    let username=params['username'];
    let password=params['password'];

    this.userService.getUserAfterLogin(username,password)
    .subscribe(user=>this.user=user);
    if(this.user!=null)
    this.router.navigate(['/getuser',username,password]);

  });

}
onLogout()
{
  this.router.navigate(['/userlogin']);
}
goToOngoingTrainings()
{
  this.route.params.subscribe((params: Params)=>{
    let username=params['username'];
    let password=params['password'];

    this.userService.getUserAfterLogin(username,password)
    .subscribe(user=>this.user=user);
    if(this.user!=null)
    this.router.navigate(['/ongoingtrainings',username,password]);

  });
  
}
goToCompletedTrainings()
{
  this.route.params.subscribe((params: Params)=>{
    let username=params['username'];
    let password=params['password'];

    this.userService.getUserAfterLogin(username,password)
    .subscribe(user=>this.user=user);
    if(this.user!=null)
    this.router.navigate(['/completedtrainings',username,password]);

  });
  
}

}
