import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserLoginComponent } from './user-login/user-login.component';
import { UserSignupComponent } from './user-signup/user-signup.component';
import { GetUserComponent } from './get-user/get-user.component';
import { SearchTrainingsComponent } from './search-trainings/search-trainings.component';
import { OngoingTrainingsComponent } from './ongoing-trainings/ongoing-trainings.component';
import { CompletedTrainingsComponent } from './completed-trainings/completed-trainings.component';

const routes: Routes = [
    { path: '', redirectTo: '/userlogin', pathMatch: 'full' },
    {path: 'getuser', component: GetUserComponent},
    {path: 'getuser/:username/:password', component: GetUserComponent},
    {path: 'userlogin', component: UserLoginComponent},
    {path: 'usersignup', component: UserSignupComponent},
    {path: 'searchtrainings/:username/:password', component: SearchTrainingsComponent},
    {path: 'ongoingtrainings/:username/:password', component: OngoingTrainingsComponent},
    {path: 'completedtrainings/:username/:password', component: CompletedTrainingsComponent},
    
    
    
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})

export class AppRoutingModule { }
