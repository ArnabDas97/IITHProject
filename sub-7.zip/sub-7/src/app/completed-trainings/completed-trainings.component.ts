import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { MentorSkill } from '../mentorskill';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-completed-trainings',
  templateUrl: './completed-trainings.component.html',
  styleUrls: ['./completed-trainings.component.css']
})
export class CompletedTrainingsComponent implements OnInit {

  user:User;
  mentorSkill:MentorSkill[];
  constructor(private route:ActivatedRoute,private userService:UserService,private router:Router) { }

  ngOnInit() {
    this.route.params.subscribe((params: Params)=>{
      let username=params['username'];
      let password=params['password'];
  
      this.userService.getCompletedTrainings(username,password,"completed")
      .subscribe(mentorSkill=>this.mentorSkill=mentorSkill);
      
  });
  console.log(this.mentorSkill);
  }

}
