package com.social.imageApp.upload.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.social.imageApp.model.Media;
import com.social.imageApp.upload.dao.UploadDao;

@Service
public class UploadServiceImpl implements UploadService {

	private UploadDao uploadDao;
	
	@Autowired(required = true)
	@Qualifier(value = "uploadDao")
	public void setUploadDao(UploadDao uploadDao) {
		this.uploadDao = uploadDao;
	}

	@Transactional
	public Media saveSingleMedia(Media media) {
		
		return uploadDao.saveSingleMedia(media);
	}

}
