package com.social.imageApp.account.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;

import com.social.imageApp.model.Activity;
import com.social.imageApp.model.User;

public class AccountDaoImpl implements AccountDao {

	private SessionFactory sessionFactory;
	
	private Activity activity = new Activity();
	private SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
	private SimpleDateFormat sdf2 = new SimpleDateFormat("HH:mm:ss");

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public User registerUser(User user) {
		sessionFactory.getCurrentSession().save(user);
		return user;
	}

	
	public User checkUser(User user) {
		Query q = sessionFactory.getCurrentSession().createQuery("from User u where u.username = :username and u.password = :password");
		q.setParameter("username", user.getUsername());
		q.setParameter("password", user.getPassword());
		User user1 =(User) q.uniqueResult();
		return user1;
	}


	public User checkUserName(String username) {
		Query q = sessionFactory.getCurrentSession().createQuery("from User u where u.username = :username");
		q.setParameter("username", username);
		User user = (User) q.uniqueResult();
		return user;
	}


	public User updateUser(User user) {
		sessionFactory.getCurrentSession().saveOrUpdate(user);
		activity.setActivity("Updated User Details");
		activity.setUserId(user.getUserId());
		Date date = new Date();
		activity.setDate(sdf1.format(date));
		activity.setTime(sdf2.format(date));
		
		sessionFactory.getCurrentSession().save(activity);
		return user;
			
	}

	public List<User> fetchUsers() {
		List<User> users = new ArrayList<User>();
		Query q = sessionFactory.getCurrentSession().createQuery("from User u");
		users = q.list();
		return users;
	}


	public User loadUserById(int id) {
		System.out.println(id);
		Query q = sessionFactory.getCurrentSession().createQuery("from User u where u.userId = :id");
		q.setParameter("id", id);
		User user =(User) q.uniqueResult();
		System.out.println(user);
		return user;
	}


	public List<Activity> getActivities(User user) {
		List<Activity> activityList = new ArrayList<Activity>();
		Query q = sessionFactory.getCurrentSession().createQuery("from Activity a where a.userId = :id");
		q.setParameter("id", user.getUserId());
		activityList = q.list();
		return activityList;
	}

}
