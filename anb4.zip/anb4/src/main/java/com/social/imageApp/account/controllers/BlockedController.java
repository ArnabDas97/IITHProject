package com.social.imageApp.account.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class BlockedController {

}
