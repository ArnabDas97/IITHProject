package com.social.imageApp.account.service;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.social.imageApp.account.dao.AccountDao;
import com.social.imageApp.model.Activity;
import com.social.imageApp.model.User;

@Service
public class AccountServiceImpl implements AccountService {

	private static Logger log = Logger.getLogger(AccountServiceImpl.class);
	
	private AccountDao accountDao;
	
	public AccountDao getAccountDao() {
		return accountDao;
	}

	public void setAccountDao(AccountDao accountDao) {
		this.accountDao = accountDao;
	}

	@Transactional
	public User registerUser(User user) {
		return accountDao.registerUser(user);
		
	}

	@Transactional
	public User checkUser(User user) {
		return accountDao.checkUser(user);
	}

	@Transactional
	public User checkUserName(String username) {
		
		return accountDao.checkUserName(username);
	}

	@Transactional
	public User updateUser(User user) {
		
		return accountDao.updateUser(user);
	}

	@Transactional
	public List<User> fetchUsers() {
		return accountDao.fetchUsers();
	}

	@Transactional
	public User loadUserById(int id) {
		
		return accountDao.loadUserById(id);
	}

	@Transactional
	public List<Activity> getActivities(User user) {
		return accountDao.getActivities(user);
	}

}
