package com.social.imageApp.mymedia.service;

import java.util.List;

import com.social.imageApp.model.Comment;
import com.social.imageApp.model.Like;
import com.social.imageApp.model.Media;
import com.social.imageApp.model.User;

public interface MyMediaService {

	List<Media> getAllMedia(User user);

	Media getMediaDetails(Media media);

	List<Comment> getComments(Media media);

	Comment saveComment(Comment comment);

	Like setLike(Like like);

}
