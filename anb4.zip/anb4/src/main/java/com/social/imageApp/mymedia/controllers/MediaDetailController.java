package com.social.imageApp.mymedia.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.social.imageApp.model.Comment;
import com.social.imageApp.model.Like;
import com.social.imageApp.model.Media;
import com.social.imageApp.mymedia.service.MyMediaService;

@Controller
@RestController
public class MediaDetailController {
	private MyMediaService myMediaService;

	@Autowired(required = true)
	@Qualifier(value="myMediaService")
	public void setMyMediaService(MyMediaService myMediaService) {
		this.myMediaService = myMediaService;
	}
	
	@RequestMapping(value="/media/getMedia", method = RequestMethod.POST)
	@CrossOrigin
	public Media getMediaDetails(@RequestBody Media media) {
		media = myMediaService.getMediaDetails(media);
		System.out.println(media);
		return media;
	}
	
	@RequestMapping(value="/media/getComments", method = RequestMethod.POST)
	@CrossOrigin
	public List<Comment> getComments(@RequestBody Media media) {
		List<Comment> commentList = myMediaService.getComments(media);
		System.out.println(commentList);
		return commentList;
	}
	
	@RequestMapping(value="/media/saveComment", method = RequestMethod.POST)
	@CrossOrigin
	public Comment saveComment(@RequestBody Comment comment) {
		comment = myMediaService.saveComment(comment);
		System.out.println(comment);
		return comment;
	}
	
	@RequestMapping(value="/media/like",method = RequestMethod.POST)
	@CrossOrigin
	public Like setLike(@RequestBody Like like) {
		System.out.println(like);
		like = myMediaService.setLike(like);
		System.out.println(like);
		return like;
	}
}
