package com.social.imageApp.upload.service;

import com.social.imageApp.model.Media;

public interface UploadService {

	Media saveSingleMedia(Media media);

}
