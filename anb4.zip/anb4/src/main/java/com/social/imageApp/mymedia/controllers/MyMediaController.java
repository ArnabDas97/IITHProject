package com.social.imageApp.mymedia.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.social.imageApp.model.Media;
import com.social.imageApp.model.User;
import com.social.imageApp.mymedia.service.MyMediaService;

@Controller
@RestController
public class MyMediaController {
	
	private MyMediaService myMediaService;

	@Autowired(required = true)
	@Qualifier(value="myMediaService")
	public void setMyMediaService(MyMediaService myMediaService) {
		this.myMediaService = myMediaService;
	}
	
	
	@RequestMapping(value="/mymedia/getAll", method= RequestMethod.POST)
	@CrossOrigin
	public List<Media> getAllMedia(@RequestBody User user){
		System.out.println(user);
		List<Media> mediaList = myMediaService.getAllMedia(user);
		System.out.println(mediaList);
		return mediaList;
	}
}
