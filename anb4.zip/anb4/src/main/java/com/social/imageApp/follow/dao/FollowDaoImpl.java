package com.social.imageApp.follow.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;

import com.social.imageApp.model.Activity;
import com.social.imageApp.model.Followers;
import com.social.imageApp.model.User;

public class FollowDaoImpl implements FollowDao {

	private SessionFactory sessionFactory;
	
	private Activity activity = new Activity();
	private SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
	private SimpleDateFormat sdf2 = new SimpleDateFormat("HH:mm:ss");

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public List<Followers> fetchAll(User user) {
		List<Followers> followers = new ArrayList<Followers>();
		Query q = sessionFactory.getCurrentSession().createQuery("from Followers f where f.userId=:id");
		q.setParameter("id", user.getUserId());
		followers = q.list();
		return followers;
	}

	@Override
	public Followers follow(User user, Followers follower) {
		if(follower.getFollowing() != 'Y') {
		Query q = sessionFactory.getCurrentSession().createQuery("update Followers f set f.following=:val where f.userId = :uid and f.followerId = :fid");
		q.setParameter("val", 'Y');
		q.setParameter("uid", user.getUserId());
		q.setParameter("fid", follower.getFollowerId());
		q.executeUpdate();
		//sessionFactory.getCurrentSession().saveOrUpdate(follower);
		Query p = sessionFactory.getCurrentSession()
				.createQuery("update User u set u.followingCount=u.followingCount+ 1 where u.userId=:id");
		p.setParameter("id", user.getUserId());
		p.executeUpdate();
		
	
		
		
		Query r = sessionFactory.getCurrentSession().createQuery("update Followers f set f.follower = :val where f.userId = :uid and f.followerId = :fid");
		r.setParameter("val", 'Y');
		r.setParameter("uid", follower.getFollowerId());
		r.setParameter("fid", follower.getUserId());
		r.executeUpdate();
		}
		
		activity.setActivity("Followed " + follower.getFollowerName());
		activity.setUserId(user.getUserId());
		Date date = new Date();
		activity.setDate(sdf1.format(date));
		activity.setTime(sdf2.format(date));
		sessionFactory.getCurrentSession().save(activity);
		return follower;

	}

	@Override
	public User getUser(Integer userId) {
		Query q = sessionFactory.getCurrentSession().createQuery("from User u where u.userId =:id");
		q.setParameter("id", userId);
		User user = (User) q.uniqueResult();
		return user;
	}

	@Override
	public Followers unfollow(User user, Followers follower) {
		sessionFactory.getCurrentSession().saveOrUpdate(follower);
		/*
		 * Integer followingCount = user.getFollowingCount(); followingCount =
		 * followingCount - 1; user.setFollowingCount(followingCount);
		 * sessionFactory.getCurrentSession().saveOrUpdate(user);
		 */
		Query q = sessionFactory.getCurrentSession()
				.createQuery("update User u set u.followingCount=u.followingCount- 1 where u.userId=:id");
		q.setParameter("id", user.getUserId());
		q.executeUpdate();
		
		Query r = sessionFactory.getCurrentSession().createQuery("update Followers f set f.follower = :val where f.userId = :uid and f.followerId = :fid");
		r.setParameter("val", 'N');
		r.setParameter("uid", follower.getFollowerId());
		r.setParameter("fid", follower.getUserId());
		r.executeUpdate();
		
		activity.setActivity("Unfollowed " + follower.getFollowerName());
		activity.setUserId(user.getUserId());
		Date date = new Date();
		activity.setDate(sdf1.format(date));
		activity.setTime(sdf2.format(date));
		sessionFactory.getCurrentSession().save(activity);
		return follower;
	}

	@Override
	public Followers getFollower(int followerId, int userId) {
		Query q = sessionFactory.getCurrentSession()
				.createQuery("from Followers f where f.userId = :uid and f.followerId = :fid");
		q.setParameter("uid", userId);
		q.setParameter("fid", followerId);
		Followers follower = (Followers) q.uniqueResult();
		if (follower != null) {
			return follower;
		} else {
			return null;
		}
	}

	@Override
	public Followers createFollower(User user, Followers follower) {
		sessionFactory.getCurrentSession().saveOrUpdate(follower);
		Query q = sessionFactory.getCurrentSession()
				.createQuery("update User u set u.followingCount=u.followingCount+ 1 where u.userId=:id");
		q.setParameter("id", user.getUserId());
		q.executeUpdate();
		
		Followers follower1 = new Followers();
		follower1.setFollower('Y');
		follower1.setUserId(follower.getFollowerId());
		follower1.setFollowerId(follower.getUserId());
		follower1.setFollowerName(user.getUsername());
		follower1.setFollowerPicture(user.getProfilePicture());
		sessionFactory.getCurrentSession().saveOrUpdate(follower1) ;
		
		activity.setActivity("Followed " + follower.getFollowerName());
		activity.setUserId(user.getUserId());
		Date date = new Date();
		activity.setDate(sdf1.format(date));
		activity.setTime(sdf2.format(date));
		sessionFactory.getCurrentSession().save(activity);
		return follower;

	}
}
