package com.social.imageApp.upload.controllers;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.social.imageApp.model.Media;
import com.social.imageApp.upload.service.UploadService;

@Controller
@RestController
public class UploadSingleMediaController {

	private UploadService uploadService;

	@Autowired(required = true)
	@Qualifier(value = "uploadService")
	public void setUploadService(UploadService uploadService) {
		this.uploadService = uploadService;
	}

	@RequestMapping(value = "/media/uploadSingle", method = RequestMethod.POST)
	@CrossOrigin
	public Media saveSingleMedia(@RequestBody Media media) {
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		media.setUploadDate(formatter.format(date));
		SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
		media.setUploadTime(format.format(date));
		System.out.println(media);
		media = uploadService.saveSingleMedia(media);
		return media;
	}
}
