package com.social.imageApp.account.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.social.imageApp.account.service.AccountService;
import com.social.imageApp.model.User;

@RestController
@Controller
public class SignInController {

	private AccountService accountService;

	@Autowired(required = true)
	@Qualifier(value = "accountService")
	public void setCustomerService(AccountService accountService) {
		this.accountService = accountService;
	}

	@RequestMapping(value = "/account/login", method = RequestMethod.POST)
	@CrossOrigin
	public User registerUser(@RequestBody User user) {
		User user1 = accountService.checkUser(user);
		System.out.println(user);
		System.out.println(user1);

		if (user1 != null)
			return user1;
		else
			return null;
	}
}
