package com.social.imageApp.follow.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.social.imageApp.follow.dao.FollowDao;
import com.social.imageApp.model.Followers;
import com.social.imageApp.model.User;

@Service
public class FollowServiceImpl implements FollowService {

	public FollowDao followDao;
	
	@Autowired(required=true)
	@Qualifier(value="followDao")
	public void setFollowDao(FollowDao followDao) {
		this.followDao = followDao;
	}



	@Transactional
	public List<Followers> fetchAll(User user) {
		
		return followDao.fetchAll(user);
	}



	@Transactional
	public Followers follow(User user,Followers follower) {
	
		return followDao.follow(user,follower);
	}



	@Transactional
	public User getUser(Integer userId) {
		
		return followDao.getUser(userId);
	}
	
	@Transactional
	public Followers unfollow(User user,Followers follower) {
	
		return followDao.unfollow(user,follower);
	}



	@Transactional
	public Followers getFollower(int followerId, int userId) {
		return followDao.getFollower(followerId,userId);
	}

	@Transactional
	public Followers createFollower(User user,Followers follower) {
	
		return followDao.createFollower(user,follower);
	}
}
