package com.social.imageApp.upload.dao;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.hibernate.SessionFactory;

import com.social.imageApp.model.Activity;
import com.social.imageApp.model.Media;

public class UploadDaoImpl implements UploadDao{

	private SessionFactory sessionFactory;

	private Activity activity = new Activity();
	private SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
	private SimpleDateFormat sdf2 = new SimpleDateFormat("HH:mm:ss");
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Override
	public Media saveSingleMedia(Media media) {
		
		sessionFactory.getCurrentSession().save(media);
		
		activity.setActivity("Uploaded a media ");
		activity.setUserId(media.getUserId());
		Date date = new Date();
		activity.setDate(sdf1.format(date));
		activity.setTime(sdf2.format(date));
		sessionFactory.getCurrentSession().save(activity);
		return media;
	}

}
