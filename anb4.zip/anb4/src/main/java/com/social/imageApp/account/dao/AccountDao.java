package com.social.imageApp.account.dao;

import java.util.List;

import com.social.imageApp.model.Activity;
import com.social.imageApp.model.User;

public interface AccountDao {
	
	public User registerUser(User user);

	public User checkUser(User user);

	public User checkUserName(String username);

	public User updateUser(User user);

	public List<User> fetchUsers();

	public User loadUserById(int id);

	public List<Activity> getActivities(User user);

}
