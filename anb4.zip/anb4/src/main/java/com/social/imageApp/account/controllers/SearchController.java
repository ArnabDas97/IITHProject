package com.social.imageApp.account.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.social.imageApp.account.service.AccountService;
import com.social.imageApp.model.User;

@Controller
@RestController
public class SearchController {
	
	private AccountService accountService;

	@Autowired(required = true)
	@Qualifier(value = "accountService")
	public void setCustomerService(AccountService accountService) {
		this.accountService = accountService;
	}
	
	@RequestMapping(value="/account/fetchUsers", method = RequestMethod.GET)
	@CrossOrigin
	public List<User> fetchUsers(){
		List<User> users =  accountService.fetchUsers();
		System.out.println(users);
		return users;
	}
	
	
	@RequestMapping(value="/account/getUser", method = RequestMethod.POST)
	@CrossOrigin
	public User loadUserById(@RequestBody User user) {
		//System.out.println(user);
		user = accountService.loadUserById(user.getUserId());
		//System.out.println(user);
		return user;
	}
}
