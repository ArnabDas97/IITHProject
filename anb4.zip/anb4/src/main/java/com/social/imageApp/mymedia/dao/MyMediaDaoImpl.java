package com.social.imageApp.mymedia.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;

import com.social.imageApp.model.Activity;
import com.social.imageApp.model.Comment;
import com.social.imageApp.model.Like;
import com.social.imageApp.model.Media;
import com.social.imageApp.model.User;

public class MyMediaDaoImpl implements MyMediaDao {

	private SessionFactory sessionFactory;
	
	private Activity activity = new Activity();
	private SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
	private SimpleDateFormat sdf2 = new SimpleDateFormat("HH:mm:ss");

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public List<Media> getAllMedia(User user) {
		Query q = sessionFactory.getCurrentSession().createQuery("from Media m where m.userId = :id");
		q.setParameter("id", user.getUserId());
		List<Media> mediaList = new ArrayList<Media>();
		mediaList = q.list();
		return mediaList;
	}

	@Override
	public Media getMediaDetails(Media media) {
		Query q = sessionFactory.getCurrentSession().createQuery("from Media m where m.id = :id");
		q.setParameter("id", media.getId());
		media = (Media) q.uniqueResult();
		return media;
	}

	@Override
	public List<Comment> getComments(Media media) {
		List<Comment> commentList = new ArrayList<Comment>();
		Query q = sessionFactory.getCurrentSession().createQuery("from Comment c where c.mediaId = :id");
		q.setParameter("id", media.getId());
		commentList = q.list();
		return commentList;
	}

	@Override
	public Comment saveComment(Comment comment) {
		sessionFactory.getCurrentSession().save(comment);
		Query q = sessionFactory.getCurrentSession()
				.createQuery("update Media m set m.numberOfComments = m.numberOfComments+1 where m.id = :id");
		q.setParameter("id", comment.getMediaId());
		q.executeUpdate();
		
		activity.setActivity("Commented "+ comment.getComment() + " on " + comment.getMediaId());
		activity.setUserId(comment.getUserId());
		Date date = new Date();
		activity.setDate(sdf1.format(date));
		activity.setTime(sdf2.format(date));
		sessionFactory.getCurrentSession().save(activity);
		return comment;
	}

	@Override
	public Like setLike(Like like) {
		Like like1 = new Like();
		Query q = sessionFactory.getCurrentSession()
				.createQuery("from Like l where l.mediaId = :mid and l.likerId = :lid");
		q.setParameter("mid", like.getMediaId());
		q.setParameter("lid", like.getLikerId());
		like1 = (Like) q.uniqueResult();
		System.out.println(like1);
		if (like1 == null) {
			sessionFactory.getCurrentSession().saveOrUpdate(like);
			if (like.getLike() == 'Y') {
				Query r = sessionFactory.getCurrentSession()
						.createQuery("update Media m set m.likes = m.likes+1 where m.id = :id");
				r.setParameter("id", like.getMediaId());
				r.executeUpdate();
				
				activity.setActivity("Liked a post " + like.getMediaId());
				activity.setUserId(like.getLikerId());
				Date date = new Date();
				activity.setDate(sdf1.format(date));
				activity.setTime(sdf2.format(date));
				sessionFactory.getCurrentSession().save(activity);
				
			} else {
				Query r = sessionFactory.getCurrentSession()
						.createQuery("update Media m set m.unlikes = m.unlikes+1 where m.id = :id");
				r.setParameter("id", like.getMediaId());
				r.executeUpdate();
				
				activity.setActivity("Disliked a post " + like.getMediaId());
				activity.setUserId(like.getLikerId());
				Date date = new Date();
				activity.setDate(sdf1.format(date));
				activity.setTime(sdf2.format(date));
				sessionFactory.getCurrentSession().save(activity);
			}
		} else {
			System.out.println(like1);
			if (like1.getLike() == 'Y') {
				System.out.println("if");
				if (like.getLike() == 'Y') {
				} else {
					Query r = sessionFactory.getCurrentSession()
							.createQuery("update Like l set l.like = 'N' where l.id=:id");
					r.setParameter("id", like1.getId());
					r.executeUpdate();
					
					
					Query s = sessionFactory.getCurrentSession()
							.createQuery("update Media m set m.likes = m.likes-1 where m.id = :id");
					s.setParameter("id", like.getMediaId());
					s.executeUpdate();
					
					Query t = sessionFactory.getCurrentSession()
							.createQuery("update Media m set m.unlikes = m.unlikes+1 where m.id = :id");
					t.setParameter("id", like.getMediaId());
					t.executeUpdate();
					
					activity.setActivity("Disliked a post " + like.getMediaId());
					activity.setUserId(like.getLikerId());
					Date date = new Date();
					activity.setDate(sdf1.format(date));
					activity.setTime(sdf2.format(date));
					sessionFactory.getCurrentSession().save(activity);
				}
			} else {
				System.out.println("else");
				if (like.getLike() == 'N') {
				} else {
					Query r = sessionFactory.getCurrentSession()
							.createQuery("update Like l set l.like = 'Y' where l.id=:id");
					r.setParameter("id", like1.getId());
					r.executeUpdate();
					
					
					Query s = sessionFactory.getCurrentSession()
							.createQuery("update Media m set m.likes = m.likes+1 where m.id = :id");
					s.setParameter("id", like.getMediaId());
					s.executeUpdate();
					
					Query t = sessionFactory.getCurrentSession()
							.createQuery("update Media m set m.unlikes = m.unlikes-1 where m.id = :id");
					t.setParameter("id", like.getMediaId());
					t.executeUpdate();
					
					activity.setActivity("Liked a post " + like.getMediaId());
					activity.setUserId(like.getLikerId());
					Date date = new Date();
					activity.setDate(sdf1.format(date));
					activity.setTime(sdf2.format(date));
					sessionFactory.getCurrentSession().save(activity);
				}
			}
		}
		
		return like;
	}

}
