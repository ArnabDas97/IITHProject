package com.social.imageApp.follow.dao;

import java.util.List;

import com.social.imageApp.model.Followers;
import com.social.imageApp.model.User;

public interface FollowDao {

	List<Followers> fetchAll(User user);

	Followers follow(User user,Followers follower);

	User getUser(Integer userId);

	Followers unfollow(User user,Followers follower);

	Followers getFollower(int followerId, int userId);

	Followers createFollower(User user, Followers follower);
}
