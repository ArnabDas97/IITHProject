export class Blocked{

    public id : number;
    public userId : number;
    public blockedId : number;
    public username : string;
    public blockedUser : string;

    constructor(){}
}