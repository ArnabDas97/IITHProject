

import { MentorSkill } from './mentorskill';
export class Mentor{
username:string;
linkedinUrl:string;
password:string;
contact:number;
regDatetime:string;
regCode:number;
// self_rating:number;
// yoe:number;
// trainings_delivered:number;
// technology_name:string;
// prerequites:string;
// toc:string;
// start_date:string;
// end_date:string;

mentorskills:MentorSkill[];
}