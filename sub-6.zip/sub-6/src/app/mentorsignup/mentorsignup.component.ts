import { Component, OnInit } from '@angular/core';
import { MentorService } from '../mentor.service';
import { Mentor } from '../mentor';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mentorsignup',
  templateUrl: './mentorsignup.component.html',
  styleUrls: ['./mentorsignup.component.css']
})
export class MentorsignupComponent implements OnInit {
  mentorsi : Mentor = new Mentor();
  constructor(private router:Router,private mentorservice:MentorService) { }
  ngOnInit() {
  }
  onSubmit()
  {
    this.mentorservice.createMentor(this.mentorsi).subscribe(mentorsi => this.mentorsi=mentorsi);
    this.mentorsi=new Mentor();
    this.router.navigate(['']);

  }

}
