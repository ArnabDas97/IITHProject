import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Customer } from '../customer';

@Component({
  selector: 'app-searchno-customer',
  templateUrl: './searchno-customer.component.html',
  styleUrls: ['./searchno-customer.component.css']
})
export class SearchnoCustomerComponent implements OnInit {
  
    mobile: number;
    customers: Customer[];
  
    constructor(private dataService: CustomerService) { }
  
    ngOnInit() {
      this.mobile = 0;
    }
  
    private searchCustomers() {
      this.dataService.getCustomersByMobile(this.mobile)
        .subscribe(customers => this.customers = customers);
    }
  
    onSubmit() {
      this.searchCustomers();
    }
  }
