export class MentorSkill
    {
        id: number;
        self_rating: number;
        yoe: number;
        trainings_delivered: number;
        technology_name: string;
        prerequites: string;
        toc: string;
        start_date: string;
        end_date: string;

    }