import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private baseUrl = 'http://localhost:9558/api';

  constructor(private http: HttpClient) { }
  getMentorAfterLogin(username:string,password:string): Observable<any>{
    return this.http.get(`${this.baseUrl}`+`/mentor`+`/${username}/${password}`);
  }

  getUserAfterLogin(email:string,password:string): Observable<any>{
    return this.http.get(`${this.baseUrl}`+`/users`+`/${email}/${password}`);
  }
}
