    export class Userprofile {
        id: number;
        firstName: string;
        lastName: string;
        email: string;
        contactNumber: number;
        regCode:number;
        regDatetime :string;
        password:string;
        address: string;
    }