import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MentorService {

  private baseUrl = 'http://localhost:9558/api/mentor';

  constructor(private http: HttpClient) { }

  getMentorList(): Observable<any>{
    return this.http.get(`${this.baseUrl}`);
  }
  getMentorAfterLogin(username:string,password:string): Observable<any>{
    return this.http.get(`${this.baseUrl}/${username}/${password}`);
  }
  getMentorSKill(): Observable<any>{
    return this.http.get(`${this.baseUrl}`+`/mentorskill`);
  }
  createMentor(mentorsi: Object): Observable<any> {
    return this.http.post(`${this.baseUrl}` + `/create`, mentorsi);
  }


}
