import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TechnologyService {
  private baseUrl='http://localhost:9558/api/getTechnology';


  constructor(private http: HttpClient) { }

    getTechnologyList(): Observable<any> {
      return this.http.get(`${this.baseUrl}`);
    
  }
}
