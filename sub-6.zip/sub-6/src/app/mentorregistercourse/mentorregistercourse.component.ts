import { Component, OnInit } from '@angular/core';
import { Mregistercourse } from '../Mregistercourse';

@Component({
  selector: 'app-mentorregistercourse',
  templateUrl: './mentorregistercourse.component.html',
  styleUrls: ['./mentorregistercourse.component.css']
})
export class MentorregistercourseComponent implements OnInit {
mregisterc=new Mregistercourse();
dataarray=[];


  constructor() { }

  ngOnInit() {
    this.mregisterc=new Mregistercourse();
  this.dataarray.push(this.mregisterc);
  //console.log(this.mregisterc);
  //console.log(this.dataarray);
  }
  addForm()
  {
    this.mregisterc=new Mregistercourse();
    this.dataarray.push(this.mregisterc);
  }
  onSubmit()
  {
    // console.log(this.dataarray);
    // console.log("fdasdfsadsa");
    // console.log(this.dataarray.length);
    for(let i=0;i<this.dataarray.length;i++)
    {
      console.log(this.dataarray[i]);
    }
  }
//   deleteForm(index)
//   {
// this.dataarray.splice(index);
//   }

}
