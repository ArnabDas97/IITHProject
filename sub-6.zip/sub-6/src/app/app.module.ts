import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { CreateCustomerComponent } from './create-customer/create-customer.component';
import { CustomerDetailsComponent } from './customer-details/customer-details.component';
import { CustomersListComponent } from './customers-list/customers-list.component';
import { SearchCustomersComponent } from './search-customers/search-customers.component';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { SearchnoCustomerComponent } from './searchno-customer/searchno-customer.component';
import { MentorlandingComponent } from './mentorlanding/mentorlanding.component';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { MycourseComponent } from './mycourse/mycourse.component';
import { CreateUserComponent } from './create-user/create-user.component';
import { UsersignupComponent } from './usersignup/usersignup.component';
import { UserlandingComponent } from './userlanding/userlanding.component';
import { LoginComponent } from './login/login.component';
import { MentorsignupComponent } from './mentorsignup/mentorsignup.component';
import { MentorregistercourseComponent } from './mentorregistercourse/mentorregistercourse.component';
import { PaymentComponent } from './payment/payment.component';

@NgModule({
  declarations: [
    AppComponent,
    CreateCustomerComponent,
    CustomerDetailsComponent,
    CustomersListComponent,
    SearchCustomersComponent,
    SearchnoCustomerComponent,
    MentorlandingComponent,
    UserprofileComponent,
    MycourseComponent,
    CreateUserComponent,
    UsersignupComponent,
    UserlandingComponent,
    LoginComponent,
    MentorsignupComponent,
    MentorregistercourseComponent,
    PaymentComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
