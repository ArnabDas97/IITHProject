import { Component, OnInit } from '@angular/core';
import { Mentor } from '../mentor';
import { MentorService } from '../mentor.service';
//import { MentorSkill } from '../mentorskill';
import { Params, ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-mentorlanding',
  templateUrl: './mentorlanding.component.html',
  styleUrls: ['./mentorlanding.component.css']
})
export class MentorlandingComponent implements OnInit {
  mentor: Mentor[];
  //Musername:string
 // mentorskill:MentorSkill[]=[];

  constructor(private router:Router,private route:ActivatedRoute,private mentorservice: MentorService) { }
  ngOnInit() {
    this.route.params.subscribe((params: Params)=>{
      let Musername=params['username'];
      let Mpassword=params['password'];
      console.log(Musername,Mpassword);


      this.mentorservice.getMentorAfterLogin(Musername,Mpassword)
      .subscribe(mentor=>this.mentor);
    })
    this.save();
  }
save()
{
  
this.mentorservice.getMentorList().subscribe(mentor=>this.mentor=mentor,error => console.log(error));

}

onGoCourseRegister()
{
  this.router.navigate(['mentorregistercourse']);
}
  // onSubmit(){}
}

/*
for(let i=0;i<this.mentor.length;i++)
{
  let ms:MentorSkill[] = this.mentor[i].mentorskills;
  console.log(ms);
  console.log(this.mentor[i]);
  for(let j=0;j<ms.length;j++)
  this.mentorskill.push(ms[j]);
}





import { Component, OnInit } from '@angular/core';
import { Userprofile } from '../userprofile';
import { UserprofileService } from '../userprofile.service';

@Component({
  selector: 'app-usersignup',
  templateUrl: './usersignup.component.html',
  styleUrls: ['./usersignup.component.css']
})
export class UsersignupComponent implements OnInit {
  user: Userprofile = new Userprofile();
  submitted = false;
  constructor(private userService: UserprofileService) { }

  ngOnInit() {
  }

  newUser() : void{
    this.submitted=false;
    this.user = new Userprofile();
  }

  save()
  {

    this.userService.createUser(this.user).subscribe(user => this.user=user);
    this.user=new Userprofile();
  }
  onSubmit()
  {
    this.save();
    this.submitted=true;
    
  }


}

*/
