export class Mregistercourse
{
    technology_name:string;
    toc:string;
    startdate:string;

}