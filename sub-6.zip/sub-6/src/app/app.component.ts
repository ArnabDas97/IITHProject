import { Component } from '@angular/core';
import { Mentor } from './mentor';
import { Router } from '@angular/router';
import { MentorService } from './mentor.service';

@Component({
  selector: 'abd',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {


 mentor:Mentor[];
  //private username:Username
  constructor(private router:Router, private mentorService: MentorService) { }

  ngOnInit() {
  }
  goToLogin()
  {
    //this.mentorService.getMentorList().subscribe(mentor=>this.mentor=mentor,error => console.log(error));
    this.router.navigate(['mentorlogin']);
  }
  onLogin()
  {
  //  this.userService.getUserOnLogin()
  }


}



