package com.mod.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mod.models.Technology;

public interface TechnologyRepository extends JpaRepository<Technology, Long>{

}
