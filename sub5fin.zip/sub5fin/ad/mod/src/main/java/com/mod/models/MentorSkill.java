package com.mod.models;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "Mentor_Skill")
public class MentorSkill implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;


	@Column(name="self_rating")
	private Double selfRating;

	@Column(name="year_of_experience")
	private Integer yoe;

	@Column(name="trainings_delivered")
	private Integer trainingsDelivered ;

	@Column(name="facilities_offered")
	private String facilitiesOffered;

	@OneToOne(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	@JoinColumn(name="mentor_id",unique = true)
	private Mentor mentor;

	@ManyToMany(cascade = {CascadeType.ALL},mappedBy = "mentorSkills",targetEntity = Technology.class,fetch = FetchType.EAGER)
	private Set<Technology> technologies=new HashSet<>();
	
	

	public Set<Technology> getTechnologies() {
		return technologies;
	}


	public void setTechnologies(Set<Technology> technologies) {
		this.technologies = technologies;
	}


	public Mentor getMentor() {
		return mentor;
	}


	public void setMentor(Mentor mentor) {
		this.mentor = mentor;
	}


	public Long getId() {
		return id;
	}


	public Double getSelfRating() {
		return selfRating;
	}

	public void setSelfRating(Double selfRating) {
		this.selfRating = selfRating;
	}

	public Integer getYoe() {
		return yoe;
	}

	public void setYoe(Integer yoe) {
		this.yoe = yoe;
	}

	

	public Integer getTrainingsDelivered() {
		return trainingsDelivered;
	}


	public void setTrainingsDelivered(Integer trainingsDelivered) {
		this.trainingsDelivered = trainingsDelivered;
	}


	public String getFacilitiesOffered() {
		return facilitiesOffered;
	}


	public void setFacilitiesOffered(String facilitiesOffered) {
		this.facilitiesOffered = facilitiesOffered;
	}


	public MentorSkill() {
		super();
		// TODO Auto-generated constructor stub
	}


	public MentorSkill(Double selfRating, Integer yoe, Integer trainingsDelivered, String facilitiesOffered,
			Mentor mentor, Set<Technology> technologies) {
		super();
		this.selfRating = selfRating;
		this.yoe = yoe;
		this.trainingsDelivered = trainingsDelivered;
		this.facilitiesOffered = facilitiesOffered;
		this.mentor = mentor;
		this.technologies = technologies;
	}



}
