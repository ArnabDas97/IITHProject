package com.mod.models;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "Mentor")
public class Mentor implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "contact")
	private Long contact;

	@Column(name = "first_name")
	private String firstName;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "last_name")
	private String lastName;

	@Column(name = "linkedin_url")
	private String linkedinUrl;

	@OneToOne(mappedBy = "mentor", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private MentorCalendar mentorCalendar;

	@OneToOne(mappedBy = "mentor", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private MentorSkill mentorSkill;
	
	@Column(name = "password")
	private String password;
	
	@Column(name = "reg_code")
	private String regCode;

	@Column(name = "reg_datetime")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date regDatetime=new Date();

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "mentor", fetch = FetchType.EAGER)
	private Set<Training> trainings = new HashSet<>();
	
	@Column(name = "username")
	private String username;

	@Column(name = "valid", nullable = false, columnDefinition = "boolean default true")
	private Boolean valid = true;

	public Mentor() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Mentor(String username, String linkedinUrl, String password, Long contact, Date regDatetime, 
			MentorSkill mentorSkill, MentorCalendar mentorCalendar, Set<Training> trainings) {
		super();
		this.username = username;
		this.linkedinUrl = linkedinUrl;
		this.password = password;
		this.contact = contact;
		this.regDatetime = regDatetime;
		this.mentorSkill = mentorSkill;
		this.mentorCalendar = mentorCalendar;
		this.trainings = trainings;
		
	}

	public Long getContact() {
		return contact;
	}

	public String getFirstName() {
		return firstName;
	}

	public Long getId() {
		return id;
	}

	public String getLastName() {
		return lastName;
	}

	public String getLinkedinUrl() {
		return linkedinUrl;
	}

	public MentorCalendar getMentorCalendar() {
		return mentorCalendar;
	}

	public MentorSkill getMentorSkill() {
		return mentorSkill;
	}

	public String getPassword() {
		return password;
	}

	public String getRegCode() {
		return regCode;
	}

	public Date getRegDatetime() {
		return regDatetime;
	}

	public Set<Training> getTrainings() {
		return trainings;
	}

	public String getUsername() {
		return username;
	}

	public Boolean isValid() {
		return valid;
	}

	public void setContact(Long contact) {
		this.contact = contact;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setLinkedinUrl(String linkedinUrl) {
		this.linkedinUrl = linkedinUrl;
	}

	public void setMentorCalendar(MentorCalendar mentorCalendar) {
		this.mentorCalendar = mentorCalendar;
	}

	public void setMentorSkill(MentorSkill mentorSkill) {
		this.mentorSkill = mentorSkill;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setRegCode(String regCode) {
		this.regCode = regCode;
	}

	public void setRegDatetime(Date regDatetime) {
		this.regDatetime = regDatetime;
	}

	public void setTrainings(Set<Training> trainings) {
		this.trainings = trainings;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void setValid(Boolean valid) {
		this.valid = valid;
	}
	
	static String generate(int n) 
    { 
  
        // chose a Character random from this String 
        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                                    + "0123456789"
                                    + "abcdefghijklmnopqrstuvxyz"; 
  
        // create StringBuffer size of AlphaNumericString 
        StringBuilder sb = new StringBuilder(n); 
  
        for (int i = 0; i < n; i++) { 
  
            // generate a random number between 
            // 0 to AlphaNumericString variable length 
            int index 
                = (int)(AlphaNumericString.length() 
                        * Math.random()); 
  
            // add Character one by one in end of sb 
            sb.append(AlphaNumericString 
                          .charAt(index)); 
        } 
  
        return sb.toString(); 
    } 

}
