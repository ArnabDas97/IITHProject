package com.mod.models;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Training")
public class Training implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id; 

	private String status;
	
	@ManyToMany(cascade = {CascadeType.ALL}, fetch = FetchType.EAGER)
	@JoinTable(name="User_training", joinColumns = @JoinColumn(name="training_id"),inverseJoinColumns = @JoinColumn(name="user_id"))
	private Set<User> users=new HashSet<>();
	
	 @ManyToOne(cascade = CascadeType.ALL)
	 @JoinColumn(name="mentor_id")
	 private Mentor mentor;
	 
	 @ManyToOne(cascade = CascadeType.ALL)
	 @JoinColumn(name="technology_id")
	 private Technology technology;
	 

	 
	public Technology getTechnology() {
		return technology;
	}

	public void setTechnology(Technology technology) {
		this.technology = technology;
	}

	public Mentor getMentor() {
		return mentor;
	}

	public void setMentor(Mentor mentor) {
		this.mentor = mentor;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Set<User> getUsers() {
		return users;
	}

	public void setUsers(Set<User> users) {
		this.users = users;
	}

	


	public Training(String status, Set<User> users, Mentor mentor, Technology technology) {
		super();
		this.status = status;
		this.users = users;
		this.mentor = mentor;
		this.technology = technology;
	}

	public Training() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	


}
