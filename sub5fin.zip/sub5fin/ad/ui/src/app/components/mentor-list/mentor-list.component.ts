import { Component, OnInit } from '@angular/core';
import { MentorService } from 'src/app/services/mentor.service';
import { Router } from '@angular/router';
import { IMentor } from '../models/mentor.model';

@Component({
  selector: 'app-mentor-list',
  template: `
  <div > 
    <h1>Mentors</h1>
    <hr/>
    <div class="row">
      <div *ngFor="let mentor of mentors" class="col-md-4">
          <mentor-thumbnail (mentorBlockClick)=blockMentor($event) 
          (mentorUnblockClick)=unblockMentor($event)
          [mentors]="mentor"></mentor-thumbnail> 
      </div>
    </div>
  </div>
  `
})
export class MentorListComponent implements OnInit {
  public mentors:any;

  constructor(private mentorService: MentorService, private router:Router) { }
  
  ngOnInit() {
    this.getMentors();
  }

  getMentors() {
    this.mentorService.getMentors().subscribe(
      data => { this.mentors = data},
      err => console.error(err),
      () => console.log('mentors loaded')
    );
  }

    
  handleMentorClicked(data: any) {
    //console.log('received: ', data)
  }

  blockMentor(mentor: IMentor) {
    
    
    
    
        this.mentorService.blockMentor(mentor).subscribe(
            data => this.mentorService.getMentorById(mentor.id),
            error => console.error(error),
            () => console.log('mentor added')
            
        )
        
    
  }
  
  unblockMentor(mentor: IMentor) {
    this.mentorService.unblockMentor(mentor).subscribe(
      data => this.mentorService.getMentorById(mentor.id),
      error => console.error(error),
      () => console.log('mentor added')
      
  )
  
  }
}
