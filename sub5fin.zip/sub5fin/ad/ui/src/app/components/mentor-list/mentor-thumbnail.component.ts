import { Component, Input, Output, EventEmitter } from "@angular/core";
import { MentorService } from 'src/app/services/mentor.service';
import { Router } from '@angular/router';
import { IMentor } from '../models/mentor.model';


@Component({
    selector: 'mentor-thumbnail',
    template: `
    <div>
        <div class="well hoverwell thumbnail">
             <h2>{{ mentors?.firstName }}&nbsp;{{ mentors?.lastName }}</h2>
             <div> Username: {{mentors?.username}} </div>
             <div> LinkedIn: {{mentors?.linkedinUrl}} </div>
             <div> Contact: {{mentors?.contact}} </div>
             <div class="btn-group">
                <div class="height-gap"><div>
                <button class="btn btn-primary" (click)="handleView() ">View</button>
                <div *ngIf="mentors.valid">
                    <button class="btn btn-danger" (click)="handleBlockMe() ">Block</button>
                </div>
                <div *ngIf="!mentors.valid">
                    <button class="btn btn-success" (click)="handleUnblockMe()">Unblock</button>
                </div>
            </div>
        </div>
       
    </div>


    `,
    styles: [`
        .well div { color:#bbb;}
        .height-gap {margin-top: 10px;}
        .btn-group div{float:right;}
    `]

})

export class MentorThumbnailComponent {
    
    @Input() mentors: IMentor;
    @Output() mentorBlockClick = new EventEmitter();
    @Output() mentorUnblockClick = new EventEmitter();
    
    constructor(private router: Router){
        
    }
    handleClickMe() {
       //this.mentorClick.emit('a mentor clicked!')
    }
    handleUnblockMe(){
    
        this.mentorUnblockClick.emit(this.mentors)
        this.router.navigateByUrl('/404', {skipLocationChange: true}).then(()=>
        this.router.navigate(["/mentors"]));
    }
    handleBlockMe(){
        this.mentorBlockClick.emit(this.mentors)
        this.router.navigateByUrl('/404', {skipLocationChange: true}).then(()=>
        this.router.navigate(["/mentors"]));
        
    }
    handleView() {
        this.router.navigate(['/mentors',this.mentors.id])
    }

}