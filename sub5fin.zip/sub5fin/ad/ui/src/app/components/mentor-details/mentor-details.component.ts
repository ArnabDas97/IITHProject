import { Component } from "@angular/core";
import { MentorService } from 'src/app/services/mentor.service';
import { ActivatedRoute } from '@angular/router';

@Component({
    templateUrl: './mentor-details.component.html',
    styles: [`
        .container {padding-left: 20px; padding-right: 20px;}
    `]
})

export class MentorDetailsComponent {
    
    mentor:any
    constructor(private mentorService:MentorService, private route:ActivatedRoute) {

    }
    ngOnInit(){
        this.getMentor(this.route.snapshot.params['id']);

    }
    getMentor(id:any) {
        this.mentorService.getMentorById(id).subscribe(
          data => { this.mentor = data},
          err => console.error(err),
          () => console.log('mentor loaded')
        );
      }
}