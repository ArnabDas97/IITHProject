export interface IUser {
    id: number
    username: string
    firstName: string
    lastName: string
    email: string
    password: string
    contactNumber: number
    regCode: string
    regDatetime: Date
    address: string
    trainings: any
}