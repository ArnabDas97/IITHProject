export interface IMentor {
    id: number
    username: string
    firstName: string
    lastName: string
    contact: number
    linkedinUrl: string
    password: string
    valid: boolean
    regCode: string
    regDatetime: Date
    mentorCalendar:any
    mentorSkill: any
    trainings: any
}