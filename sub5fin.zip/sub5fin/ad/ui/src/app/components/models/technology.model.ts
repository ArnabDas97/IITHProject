export interface ITechnology {
    id: number
    name: string
    toc: string
    fees: number
    duration: number
    prerequisites: string
    mentorSkillks:any
    trainings: any

}