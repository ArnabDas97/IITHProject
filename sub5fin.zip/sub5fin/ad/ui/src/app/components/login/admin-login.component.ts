import { Component } from "@angular/core";
import { NgForm} from '@angular/forms'
@Component({
    templateUrl: './admin-login.component.html'
})
export class AdminLoginComponent {

    login(formValues){
        console.log(formValues)
    }
}