import { Component, OnInit } from '@angular/core';
import { MentorService } from 'src/app/services/mentor.service';
import { Router } from '@angular/router';
import { IMentor } from '../models/mentor.model';
import { TechnologyService } from 'src/app/services/technology.service';

@Component({
  selector: 'app-technology-list',
  template: `
  <div > 
    <h1>Technologies</h1>
    <hr/>
    <div class="row">
      <div *ngFor="let technology of technologies" class="col-md-4">
          <technology-thumbnail [technology1]="technology"></technology-thumbnail> 
      </div>
    </div>
  </div>
  `
})
export class TechnologyListComponent implements OnInit {
  public technologies:any;

  constructor(private technologyService: TechnologyService, private router:Router) { }
  
  ngOnInit() {
    this.getTechnologies();
  }

  getTechnologies() {
    this.technologyService.getTechnologies().subscribe(
      data => { this.technologies = data},
      err => console.error(err),
      () => console.log('technologies loaded')
    );
  }

    
  handleMentorClicked(data: any) {
    //console.log('received: ', data)
  }

  
}
