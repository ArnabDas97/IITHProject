import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MentorListComponent } from './components/mentor-list/mentor-list.component';
import { MentorDetailsComponent } from './components/mentor-details/mentor-details.component';
import { CreateMentorComponent } from './components/create/create-mentor.component';
import { CreateTechnologyComponent } from './components/create/create-technology.component';
import { Error404Component } from './components/errors/404.component';
import { MentorRouteActivator } from './components/mentor-details/mentor-route-activator.service';
import { AdminLoginComponent } from './components/login/admin-login.component';
import { TechnologyListComponent } from './components/technology-list/technology-list.component';



const routes: Routes = [
  {
    path: 'admin/login',
    component: AdminLoginComponent
  },
  {
    path: 'mentors/new',
    component: CreateMentorComponent
  },
  {
    path: 'technology',
    component: TechnologyListComponent
  },
  {
    path: 'technology/new',
    component: CreateTechnologyComponent
  },
  {
    path: 'mentors',
    component: MentorListComponent
  },
  
  {
    path: 'mentors/:id',
    component: MentorDetailsComponent,
    canActivate: [MentorRouteActivator]
  },
 
  
  {
    path: '404',
    component: Error404Component
  }
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
